<?php
	/*
	Plugin Name: Batakoo Extra
	Plugin URI: http://www.themesawesome.com
	Description: A plugin to add functionality to Premium Theme Batakoo from Themes Awesome
	Version: 1.1
	Author: Themes Awesome
	Author URI: http://www.themesawesome.com
	License: GPL2
	*/



define( 'BATAKOO_PORTFOLIO_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'BATAKOO_PORTFOLIO_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );



register_activation_hook( __FILE__, array( 'Batakoo Extra', 'plugin_activation' ) );
register_deactivation_hook( __FILE__, array( 'Batakoo Extra', 'plugin_deactivation' ) );




function batakoo_porfolio_admin_style() {

}
add_action( 'admin_enqueue_scripts', 'batakoo_porfolio_admin_style' );


function batakoo_portfolio_scripts() {

    if (!is_admin()) { 


    wp_enqueue_script('jquery');
    wp_enqueue_script('wp-mediaelement'); 
    } 
} 

add_action( 'wp_head', 'batakoo_portfolio_scripts',0);

/*-----------------------------------------------------------------------------------*/
/* The Portfolio custom post type
/*-----------------------------------------------------------------------------------*/
    add_action('init', 'batakoo_portfolio_register'); 
    function batakoo_portfolio_register() { 


        $labels = array(
            'name'               => _x('Portfolio', 'Portfolio General Name', 'batakoo'),
            'singular_name'      => _x('Portfolio', 'Portfolio Singular Name', 'batakoo'),
            'add_new'            => _x('Add New', 'Add New Portfolio Name', 'batakoo'),
            'add_new_item'       => __('Add New Portfolio', 'batakoo'),
            'edit_item'          => __('Edit Portfolio', 'batakoo'),
            'new_item'           => __('New Portfolio', 'batakoo'),
            'view_item'          => __('View Portfolio', 'batakoo'),
            'search_items'       => __('Search Portfolio', 'batakoo'),
            'not_found'          => __('Nothing found', 'batakoo'),
            'not_found_in_trash' => __('Nothing found in Trash', 'batakoo'),
            'parent_item_colon'  => ''
        );

        $args = array(
            'labels'             => $labels,
            'public'             => true,
            'publicly_queryable' => true,
            'show_ui'            => true,
            'query_var'          => 'portfolio',
            'capability_type'    => 'post',
            'hierarchical'       => false,
            'rewrite'            => false,
            'supports'           => array('title','editor','thumbnail'),

            'exclude_from_search' => true,

        ); 

        register_post_type('batakoo-portfolio' , $args);
            
        register_taxonomy(
                "portfolio-category", array("batakoo-portfolio"), array(
                "hierarchical"   => true,
                "label"          => "Categories", 
                "singular_label" => "Categories", 
                "rewrite"        => true));
        register_taxonomy_for_object_type('portfolio-category', 'batakoo-portfolio');  

    }
            
    function batakoo_portfolio_edit_columns($columns) {  
        $columns = array(  
            "cb"          => "<input type=\"checkbox\" />",  
            "title"       => __('Project', 'batakoo'),  
            "type"        => __('Categories', 'batakoo'),  
        );    
        return $columns;  
    }    

    add_filter("manage_edit-portfolio_columns", "batakoo_portfolio_edit_columns"); 


       
    function batakoo_portfolio_custom_columns($column) {  
        global $post;  
        switch ($column) {  

            case "type":  
                echo get_the_term_list($post->ID, 'portfolio-category', '', ', ','');  
                break;         
        }  
    }    

    add_action("manage_posts_custom_column",  "batakoo_portfolio_custom_columns");

/*-----------------------------------------------------------------------------------*/
/* The Testimonial custom post type
/*-----------------------------------------------------------------------------------*/


if ( ! function_exists('batakoo_testimonial_register') ) {

// Register Custom Post Type
function batakoo_testimonial_register() {

    $labels = array(
        'name'                => _x( 'Testimonial', 'Post Type General Name', 'batakoo' ),
        'singular_name'       => _x( 'Testimonial', 'Post Type Singular Name', 'batakoo' ),
        'menu_name'           => __( 'Testimonial', 'batakoo' ),
        'parent_item_colon'   => __( 'Parent Testimonial:', 'batakoo' ),
        'all_items'           => __( 'All Testimonial', 'batakoo' ),
        'view_item'           => __( 'View Testimonial', 'batakoo' ),
        'add_new_item'        => __( 'Add New Testimonial', 'batakoo' ),
        'add_new'             => __( 'Add New', 'batakoo' ),
        'edit_item'           => __( 'Edit Testimonial', 'batakoo' ),
        'update_item'         => __( 'Update Testimonial', 'batakoo' ),
        'search_items'        => __( 'Search Testimonial', 'batakoo' ),
        'not_found'           => __( 'Not found', 'batakoo' ),
        'not_found_in_trash'  => __( 'Not found in Trash', 'batakoo' ),
    );
    $args = array(
        'label'               => __( 'batakoo_testimonial', 'batakoo' ),
        'description'         => __( 'Testimonial post', 'batakoo' ),
        'labels'              => $labels,
        'supports'            => array( 'title', 'editor', 'thumbnail', ),
        'hierarchical'        => false,
        'public'              => true,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'show_in_nav_menus'   => true,
        'show_in_admin_bar'   => true,
        'menu_position'       => 5,
        'can_export'          => true,
        'has_archive'         => true,
        'exclude_from_search' => true,
        'publicly_queryable'  => true,
        'capability_type'     => 'page',
    );
    register_post_type( 'batakoo_testimonial', $args );

}

// Hook into the 'init' action
add_action( 'init', 'batakoo_testimonial_register', 0 );

}

/*-----------------------------------------------------------------------------------*/
/* The Partner custom post type
/*-----------------------------------------------------------------------------------*/

if ( ! function_exists('batakoo_partner_register') ) {

// Register Custom Post Type
function batakoo_partner_register() {

    $labels = array(
        'name'                => _x( 'Partner', 'Post Type General Name', 'batakoo' ),
        'singular_name'       => _x( 'Partner', 'Post Type Singular Name', 'batakoo' ),
        'menu_name'           => __( 'Partner', 'batakoo' ),
        'parent_item_colon'   => __( 'Parent Partner:', 'batakoo' ),
        'all_items'           => __( 'All Partner', 'batakoo' ),
        'view_item'           => __( 'View Partner', 'batakoo' ),
        'add_new_item'        => __( 'Add New Partner', 'batakoo' ),
        'add_new'             => __( 'Add New', 'batakoo' ),
        'edit_item'           => __( 'Edit Partner', 'batakoo' ),
        'update_item'         => __( 'Update Partner', 'batakoo' ),
        'search_items'        => __( 'Search Partner', 'batakoo' ),
        'not_found'           => __( 'Not found', 'batakoo' ),
        'not_found_in_trash'  => __( 'Not found in Trash', 'batakoo' ),
    );
    $args = array(
        'label'               => __( 'batakoo_partner', 'batakoo' ),
        'description'         => __( 'Partner post', 'batakoo' ),
        'labels'              => $labels,
        'supports'            => array( 'title', 'editor', 'thumbnail', ),
        'hierarchical'        => false,
        'public'              => true,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'show_in_nav_menus'   => true,
        'show_in_admin_bar'   => true,
        'menu_position'       => 5,
        'can_export'          => true,
        'has_archive'         => true,
        'exclude_from_search' => true,
        'publicly_queryable'  => true,
        'capability_type'     => 'page',
    );
    register_post_type( 'batakoo_partner', $args );

}

// Hook into the 'init' action
add_action( 'init', 'batakoo_partner_register', 0 );

}

/*-----------------------------------------------------------------------------------*/
/* The FAQ custom post type
/*-----------------------------------------------------------------------------------*/

if ( ! function_exists('batakoo_faq_register') ) {

// Register Custom Post Type
function batakoo_faq_register() {

    $labels = array(
        'name'                => _x( 'FAQ', 'Post Type General Name', 'batakoo' ),
        'singular_name'       => _x( 'FAQ', 'Post Type Singular Name', 'batakoo' ),
        'menu_name'           => __( 'FAQ', 'batakoo' ),
        'parent_item_colon'   => __( 'Parent FAQ:', 'batakoo' ),
        'all_items'           => __( 'All FAQ', 'batakoo' ),
        'view_item'           => __( 'View FAQ', 'batakoo' ),
        'add_new_item'        => __( 'Add New FAQ', 'batakoo' ),
        'add_new'             => __( 'Add New', 'batakoo' ),
        'edit_item'           => __( 'Edit FAQ', 'batakoo' ),
        'update_item'         => __( 'Update FAQ', 'batakoo' ),
        'search_items'        => __( 'Search FAQ', 'batakoo' ),
        'not_found'           => __( 'Not found', 'batakoo' ),
        'not_found_in_trash'  => __( 'Not found in Trash', 'batakoo' ),
    );
    $args = array(
        'label'               => __( 'batakoo_faq', 'batakoo' ),
        'description'         => __( 'FAQ post', 'batakoo' ),
        'labels'              => $labels,
        'supports'            => array( 'title', 'editor', 'thumbnail', ),
        'hierarchical'        => false,
        'public'              => true,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'show_in_nav_menus'   => true,
        'show_in_admin_bar'   => true,
        'menu_position'       => 5,
        'can_export'          => true,
        'has_archive'         => true,
        'exclude_from_search' => true,
        'publicly_queryable'  => true,
        'capability_type'     => 'page',
    );
    register_post_type( 'batakoo_faq', $args );

}

// Hook into the 'init' action
add_action( 'init', 'batakoo_faq_register', 0 );

}